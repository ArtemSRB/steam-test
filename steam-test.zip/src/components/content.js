import React, { Component } from 'react';
import ReactCountryFlag from 'react-country-flag';
import {
    Profile,
    Avatar,
    Info,
} from './Css'
class Content extends Component {
    constructor() {
        super();
        this.state = {
            error: null,
            isLoaded: false,
            items: [],
            value:''
        };


    }
        // http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=7A5F85FA779E5B3887295BDD14C3C2BC&steamids=76561198058962210
        // fetch('api.openweathermap.org/data/2.5/weather?q='+ city +'')
        // fetch('http://api.openweathermap.org/data/2.5/weather?q=London&appid=b1b35bba8b434a28a0be2a3e1071ae5b&units=imperial')
    render(){

        const {error, data} = this.props;
        console.log(data);
        let raw_time = parseInt( data.timecreated ) * 1000 ;
        let the_date = new Date( raw_time );
        let formatted_date = the_date.toDateString();
        if (error) {
            return <div>Error: {error.message}</div>;
        } else if (!data) {
            return <div>Loading...</div>;
        } else {
            return (
                <Profile>
                    <Avatar><img src={data.avatarfull} alt="avatar" />
                        <a href={data.profileurl} target="_blank">Go to Profile</a>
                    </Avatar>
                    <Info>
                        <p>{data.steamid}</p>
                        <p className="status">Online Status — <span className={data.personastate === 0 ? 'offline' : 'online'}>{data.personastate === 0 ? 'offline' : 'online'}</span></p>
                    <p>Date registration — {formatted_date}</p>
                    <p>Location — <ReactCountryFlag  code={data.loccountrycode} svg /></p>
                        <a href="/game" >Game Profile</a>
                    </Info>
                </Profile>
            );
        }
    }
}

export default Content;